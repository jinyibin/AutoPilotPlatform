Profile Name:vybrid-sd-uboot
Board Name: TWR
Description:Download the u-boot for vybrid to the SD card.

Profile Name: vybrid-sd-led
Board Name: TWR
Description:Download the led sample, which is a basic toggle led test that boots from SD card.

Profile Name:vybrid-qspi-uboot
Board Name: TWR
Description:Download the u-boot for vybrid QuadSPI.

Profile Name:vybrid-qspi-led
Board Name: TWR
Description:Download the led sample, which is a basic toggle led test that boots from QuadSPI.

Profile Name:vybrid-nand-uboot
Board Name: TWR
Description:Download the u-boot for vybrid NAND.

Profile Name:vybrid-nand-led
Board Name: TWR
Description:Download the led sample, which is a basic toggle led test that boots from NAND.

